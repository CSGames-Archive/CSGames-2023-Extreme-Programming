You must multiply two numbers without using the operators * and /, with a limited number of = and taking into account all whole numbers.

### Input
1. The first line contains the number N > 0 which is the number of multiplications to do.
2. The N next lines contain the two numbers to multiply.

```
2
9 3
-2 1
```

### Output
```
27
-2
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
for      | 1
while    | 0
+        | 1
-        | 2
*        | 0
/        | 0
++       | 0
--       | 0
%        | 0
=        | 2
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0