Vous devez faire la somme de deux nombres sans utiliser *aucun* opérateur arithmétique. Vous retrouverez la liste complète des mots clefs restreints plus bas.

Peut-être que certaines fonctions peuvent vous aider...

### Entrée
1. La première ligne contient le nombre entier N, soit le nombre d'additions à faire.
2. Les N prochaines lignes contiennent les deux nombres à additionner.

```
2
3 4
13 8
```

### Sortie
```
7
21
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
+        | 0
-        | 0
*        | 0
/        | 0
++       | 0
--       | 0
%        | 0
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0