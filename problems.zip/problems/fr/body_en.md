You have to add two numbers without any arithmetic operator.  You will find the complete list of the restricted keywords below.

Maybe some functions can help you...

### Input
1. The first line contains the integer N, which is the number of summation to do.
2. The N next lines contain two numbers to add.

```
2
3 4
13 8
```

### Output
```
7
21
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
+        | 0
-        | 0
*        | 0
/        | 0
++       | 0
--       | 0
%        | 0
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0