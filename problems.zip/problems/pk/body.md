Le Pakistan a banni tous les opérateurs arithmétiques.  Ils croient que la multiplication par 2 est la seule opération nécessaire au bon fonctionnement de la société.

### Entrée
1. La première ligne contient le nombre entier N, soit le nombre de multiplications à faire.
2. Les N prochaines lignes contiennent les nombres à multiplier par 2.

```
2
3
13
```

### Sortie
```
6
26
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
=        | 2
*        | 0
/        | 0
%        | 0
+        | 0
-        | 0
++       | 0
--       | 0
sum      | 0
add      | 0
mult     | 0
for      | 1
while    | 0
accumulate | 0
math | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0