Pakistan has banned all arithmetic operators. They believe that multiplying by 2 is the only operation necessary for the proper functioning of society.

### Input
1. The first line contains the whole number N, i.e., the number of multiplications to be done.
2. The next N lines contain the numbers to be multiplied by 2.

```
2
3
13
```

### Output
```
6
26
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
=        | 2
*        | 0
/        | 0
%        | 0
+        | 0
-        | 0
++       | 0
--       | 0
sum      | 0
add      | 0
mult     | 0
for      | 1
while    | 0
accumulate | 0
math | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0