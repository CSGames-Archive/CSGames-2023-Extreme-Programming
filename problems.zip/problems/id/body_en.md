You must do a multiplication of two positive numbers without using the operators * and /.

### Input
1. The first line contains the integer N> 0, the number of multiplications to do.
2. The next N lines contain the two numbers to be multiplied. Note that these numbers are all greater than or equal to 0.

```
2
9 3
2 2
```

### Output
```
27
4
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
for      | 1
while    | 0
+        | 1
-        | 1
*        | 0
/        | 0
++       | 0
--       | 0
%        | 0
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0