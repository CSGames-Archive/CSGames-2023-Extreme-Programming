Le Brésil a plus de 60 % de la forêt amazonienne sur son territoire.  Ils ont appris, avec le temps, comment s'y promener en *pré-ordre* et en *post-order*, mais ils ont encore un peu de difficulté en *en ordre*.

Votre objectif est de prendre en paramètre le résultat d'un parcours *pré-ordre* et *post-ordre* d'un arbre et de retourner le chemin *ordre* afin de les aider à se guider dans la forêt !

Exemple : 

Chemin pré-ordre: 2 4 9 3 6

Chemin post-ordre: 9 3 4 6 2

L'arbre résultant est le suivant:

<pre>
    2
   / \
  4   6
 / \
9   3
</pre>

Et le chemin ordre est: 9 4 3 2 6

### Entrée
1. Chemin pré-ordre des noeuds visité dans l'arbre.
2. Chemin post-ordre des noeuds visité dans l'arbre.

```
2 4 9 3 6
9 3 4 6 2
```

### Sortie
Il faut retourner le chemin en ordre des noeuds visité dans l'arbre.
```
9 4 3 2 6
```

### Restrictions

Aucune restriction.