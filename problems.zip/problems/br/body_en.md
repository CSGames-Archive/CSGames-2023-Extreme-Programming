Brazil have more than 60% of the Amazon forest on its territory. They have learned how to walk there in *preorder* and in *postorder*, but they still have a little difficulty in *inorder*.

Your objective is to take as a parameter the result of a *preorder* and *postorder* traversal of a tree and to return the * inorder * traversal to help them guide themselves in the forest!

Example : 

Preorder traversal: 2 4 9 3 6

Postorder traversal: 9 3 4 6 2

The resulting tree is the following:

<pre>
    2
   / \
  4   6
 / \
9   3
</pre>

And the inorder traversal is: 9 4 3 2 6

### Input
1. Preorder path of the nodes visited in the tree.
2. Postorder path of the nodes visited in the tree.

```
2 4 9 3 6
9 3 4 6 2
```

### Output
You must return the inorder path of the nodes visited in the tree.
```
9 4 3 2 6
```

### Restrictions

None.