Le premier cas serait survenu lorsque la personne aurait bu une Heineken alors qu'il avait la grippe.  Le résultat est catastrophique.  Le gouvernement étudie présentement le virus et grâce aux expériences de la Thaïlande et des pingouins de Madagascar, ils ont réussi à avancer dans leur étude et à déterminer que le virus n'agis pas tout à fait de la même façon selon son emplacement.

Lors de l'explosion, si le virus est sur une case **paire**, il va aller vers les cellules **adjacentes** (haut, bas, droite et gauche).
Lorsqu'il est sur une case **impaire**, il va aller vers les cellules en **diagonales** (coin droit supérieur, coin gauche supérieur, coin droit inférieur, coin gauche inférieur).

<pre>
   pair          impair   Numéro des cellules*
   ---            ---             ---
000   010      000   101          012
030 > 1X1      030 > 0X0          345
000   010      000   101          678

*On suppose que 0 est un nombre pair.
</pre>

Bien sûr, les anciennes règles s'appliquent toujours :
1. Chaque seconde est représentée par une itération.
2. Le virus prend 3 secondes (ou 3 itérations) pour maturer dans une cellule et exploser.
3. Lorsque le virus explose, il contamine les cellules adjacentes non infectées.
5. Certaines cases n'ont **pas de cellules**.
6. Lorsqu'une cellule avec un virus explose, le virus se propage au maximum de **deux cases avant de mourir**.
7. Lorsqu'une cellule explose, elle **meurt définitivement** !

Voici un exemple:

<pre>
  0       1       2       3       4       5       6     ...
X2X0    X3X0    XXX0    XXX0    XXX0    XXX0    XXX0
10X0 -> 20X0 -> 30X0 -> X1X0 -> X2X0 -> X3X0 -> XXX0 -> ...
X000    X000    X001    X002    X003    X00X    X01X
</pre>

* Les cellules non infectées sont à 0.
* Les cellules infectées sont représentées par 1, 2 et 3.
* Les X représentent l'absence de cellule à cet endroit.

### Entrée
1. La première ligne contient m (Nombre de rangées), n (Nombre de colonnes) et k (Nombre d'itérations).
2. Les lignes suivantes contiennent l'état des cellules à l'état initial (k=0).

```
2 3 3
0X1 
20X
```

---
**À l'état initial, une cellule peut être infectée à un état avancé (donc avoir une valeur de 1, 2 ou 3).**

---

### Sortie
Il faut retourner l'état de la simulation après k itérations.
```
1XX
X0X
```

### Restrictions

Aucune restriction.