The first case would have occurred when the person had a Heineken while having the flu. The result is catastrophic. The government is currently studying the virus and thanks to the experiences of Thailand and the penguins of Madagascar, they found that the virus does not act in quite the same way depending on its location.

During the explosion, if the virus is on a ** even ** cell, it will go to the adjacent ** cells ** (top, bottom, right and left).
When it is on a ** odd ** cell, it will go to the cells in ** diagonal ** (upper right corner, upper left corner, lower right corner, lower left corner).

<pre>
   even          odd         Id of the cell*
   ---            ---             ---
000   010      000   101          012
030 > 1X1      030 > 0X0          345
000   010      000   101          678

*We supposed that 0 is an even number.
</pre>

Of course, the old rules still apply:
1. Each second is represented by an iteration.
2. The virus takes 3 seconds (or 3 iterations) to mature in a cell and explode.
3. When the virus explodes, it infects adjacent uninfected cells.
5. Some boxes have ** no cells **.
6. When a cell with a virus explodes, the virus spreads by a maximum of ** two cells before dying **.
7. When a cell explodes, it ** dies definitively **!

Here is an example:

<pre>
  0       1       2       3       4       5       6     ...
X2X0    X3X0    XXX0    XXX0    XXX0    XXX0    XXX0
10X0 -> 20X0 -> 30X0 -> X1X0 -> X2X0 -> X3X0 -> XXX0 -> ...
X000    X000    X001    X002    X003    X00X    X01X
</pre>

* Uninfected cells are at 0.
* The infected cells are represented by 1, 2 and 3.
* The Xs represent the absence of cells at this location.

### Input
1. The first line contains m (Number of rows), n (Number of columns) and k (Number of iterations).
2. The following lines contain the state of the cells in the initial state (k=0).

```
2 3 3
0X1 
20X
```

---
**In the initial state, a cell can be infected in an advanced state (therefore have a value of 1, 2 or 3).**

---

### Output
Return the state of the simulation after k iterations
```
1XX
X0X
```

### Restrictions

None.