Already being a perfect country, Canada does not need your help. So it decided to offer you explanations to help you understand how this interface works.

Standard inputs and outputs are used. Here are skeletons of code to print your answer:

####Python
```python
print("Hello, World!")
```

####C++
```cpp
#include <iostream>

using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
```

####C
```c
#include <stdio.h>

int main() {
    printf("Hello, World!\n");
    return 0;
}
```

####Java
```java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```

####Perl
```perl
print "Hello, World!"
```

### Input

*This section defines the entry and gives an example of a possible input.*

None.

### Output

*This section indicates the expected output with the input given as an example in the previous section.*

You need to return this string :

```
I know how it works
```

### Restrictions

*This section indicates the restricted characters or the code length limit if any. Your code must not exceed the quantity allowed if specified.*

None.