Étant déjà un pays parfait, le Canada n'a pas besoin de votre aide.  Il a donc décidé de vous offrir des explications pour vous aider à comprendre comment cette interface fonctionne.

Les entrées et les sorties standards sont utilisées.  Voici des squelettes de code pour envoyer un résultat:

####Python
```python
print("Hello, World!")
```

####C++
```cpp
#include <iostream>

using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
```

####C
```c
#include <stdio.h>

int main() {
    printf("Hello, World!\n");
    return 0;
}
```

####Java
```java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```

####Perl
```perl
print "Hello, World!"
```

### Entrée

*Cette section définit l'entrée et donne un exemple d'entrée possible.*

Aucune.

### Sortie

*Cette section indique la sortie attendue avec l'entrée donnée en exemple à la section précédente.*

Vous devez retourner le texte suivant :

```
I know how it works
```

### Restrictions

*Cette section indique les caractères restreints ou la quantité de caractères maximum s'il y a lieu.  Votre code ne devra pas dépasser la quantité permise si indiquée.*

Aucune.