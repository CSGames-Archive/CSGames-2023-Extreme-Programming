Since Occupation Double, Mali sees that there is a lot of potential money with reality-shows. The government wants an algorithm to be able to sort the results of the votes of the audience for the other shows they will make.

Your mandate: Write a ** efficient ** sorting algorithm. An O(n^2) algorithm will not work.

** BE CAREFUL !  Java will not work here ! **

### Input
1. The first line N contains the number of lines containing numbers.
2. The next N lines all contain 20 numbers separated by a space.

```
2
6 11 31 38 19 0 -32 -2 -4 -8 32 -32 -10 39 -15 23 -34 -18 39 -24
15 -17 0 14 30 -26 -16 -11 -22 -17 -23 20 3 30 25 5 -40 -4 -1 20
```

### Output
Return the sorted numbers separated by a space.
Each line must contain exactly 20 numbers.
```
-40 -34 -32 -32 -26 -24 -23 -22 -18 -17 -17 -16 -15 -11 -10 -8 -4 -4 -2 -1
0 0 3 5 6 11 14 15 19 20 20 23 25 30 30 31 32 38 39 39
```

BE CAREFUL of formatting. There is ** no spaces ** at the end of the lines!

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
sort | 0
order | 0
set | 0
map | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0