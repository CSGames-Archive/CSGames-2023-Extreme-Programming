Depuis Occupation Double, le Mali voit qu'il y a beaucoup d'argent à faire avec les télé-réalités.  Le gouvernement veut un algorithme pour pouvoir trier les résultats des votes de l'auditoire pour les prochaines émissions qu'ils vont faire.

Votre mandat : Écrire un algorithme de tri **performant**.  Un algorithme en O(n^2) ne fonctionnera pas.

** ATTENTION !  Java ne fonctionnera pas pour ce défi ! **

### Entrée
1. La première ligne N contient le nombre de lignes contenant des nombres.
2. Les N prochaines lignes contiennent toutes 20 nombres séparés par un espace.

```
2
6 11 31 38 19 0 -32 -2 -4 -8 32 -32 -10 39 -15 23 -34 -18 39 -24
15 -17 0 14 30 -26 -16 -11 -22 -17 -23 20 3 30 25 5 -40 -4 -1 20
```

### Sortie
Retourner les nombres triés séparés par un espace.
Chaque ligne doit contenir exactement 20 nombres.
```
-40 -34 -32 -32 -26 -24 -23 -22 -18 -17 -17 -16 -15 -11 -10 -8 -4 -4 -2 -1
0 0 3 5 6 11 14 15 19 20 20 23 25 30 30 31 32 38 39 39
```

ATTENTION au formatage.  Il ne faut **pas d'espace** à la fin des lignes !

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
sort | 0
order | 0
set | 0
map | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0