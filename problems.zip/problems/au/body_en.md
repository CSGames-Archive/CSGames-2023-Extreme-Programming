Now that the country's colors are red (fire) and black (ash), the government would like to move from AVL trees to red-black trees. Despite the fact that they do not have the code, they left you the rules that the red-black tree must perform for the insertion of a new node!

1. If the ** parent ** of a new node is ** black **: do nothing.
1. If the ** parent ** of a new node is ** red ** and the ** brother of the parent ** is ** black **: the parent becomes black, the grandparent becomes red and we rotate at the level of the grandparent to move up the new node.
1. ** BE CAREFUL ** If we are in ** case 2 ** but the new node is either ** to the right of the left subtree of the grandparent ** or ** to the left of the right subtree of the grandparent **, you must rotate at the parent level first, then perform case 2.
1. The ** parent ** and the ** brother of the parent ** of the new node are ** red **: The ** parent ** and ** uncle ** become ** black ** and the ** grandparent ** becomes ** red **. Then, ** consider ** the ** grandparent ** as a ** new ** node that has just been inserted and ** apply the rules to it if necessary **.

Remember that the red-black tree is a ** binary search tree **, so the left childrens of a node are all smaller and those on its right are all bigger.

### Input
1. The nodes, in order, to be added to the red-black tree.
```
3 7 9 2 8
```

### Output
You must return the **preorder** path of the nodes visited in the red-black tree that you created.
```
7 3 2 9 8
```

### Restrictions

No restriction.