Maintenant que les couleurs du pays sont le rouge (feu) et le noir (cendre), le gouvernement aimerait passer des arbres AVL aux arbres rouge-noir.  Malgré le fait qu'ils n'ont pas le code, ils vous ont laissé les règles que l'arbre rouge-noir doit effectuer pour l'insertion d'un nouveau noeud!  

1. Si le **parent** d'un nouveau noeud est **noir**: ne rien faire.
1. Si le **parent** d'un nouveau noeud est **rouge** et le **frère du parent** est **noir**: le parent devient noir, le grand-parent devient rouge et on effectue une rotation au niveau du grand-parent pour remonter le nouveau noeud.
1. **ATTENTION!**  Si on se retrouve dans le **cas 2** mais que le nouveau noeud est soit **à la droite du sous-arbre gauche du grand-parent** ou **à la gauche du sous-arbre droit du grand-parent**, il faut effectuer une rotation au niveau du parent en premier, puis effectuer le cas 2 par la suite.
1. Le **parent** et le **frère du parent** du nouveau noeud sont **rouges**: Le **parent** et **l'oncle** deviennent **noirs** et le **grand-parent** devient **rouge**.  Ensuite, il faut **considéré** le **grand-parent** comme un **nouveau** noeud qui vient d'être inséré et **y appliquer les règles au besoin**.

N'oubliez pas que l'arbre rouge-noir est un **arbre de recherche binaire**, donc les enfants à la gauche d'un noeud sont tous plus petits que celui-ci et ceux à sa droite sont tous plus grands.

### Entrée
1. Les noeuds, dans l'ordre, à ajouter dans l'arbre rouge-noir.

```
3 7 9 2 8
```

### Sortie
Il faut retourner le chemin **préordre** des noeuds visité dans l'arbre rouge-noir que vous avez créé.
```
7 3 2 9 8
```

### Restrictions

Aucune restriction.