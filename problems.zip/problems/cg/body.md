Le voisin de la RDC, le Congo, a aussi besoin de votre aide pour déterminer si un nombre est une puissance de 2 avec un **nombre de caractères limités** plus petit.

Il ont un ordinateur avec une quantité de mémoire très limitée !  Donc vous devez écrire un code encore plus petit !

### Entrée

Un seul nombre N > 0. Exemple:
```
4
```

### Sortie

Vous devez retourner 1 si c'est une puissance de 2, 0 sinon. Exemple avec l'entrée 4: 

```
1
```

### Restrictions

**IL EST FORTEMENT RECOMMANDÉ D'UTILISER PYTHON POUR CE PROBLÈME.**

Nombre maximum de caractères: 45