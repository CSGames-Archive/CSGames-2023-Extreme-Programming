The DRC's neighbour, Republic of the Congo, also needs your help to determine if a number is a power of 2 with a smaller ** limited number of characters **.

They have a very limited quantity of memory !  So your code should be even smaller !

### Input

One number N > 0. Example:
```
4
```

### Output

Return 1 if the number is a power of two, 0 otherwise.  Example with the input 4 :

```
1
```

### Restrictions

**IT IS HIGHLY RECOMMENDED TO USE PYTHON FOR THIS PROBLEM.**

Code length limit: 45