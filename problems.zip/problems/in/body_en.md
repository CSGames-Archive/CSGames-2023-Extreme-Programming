India has also passed a law similar to the on in Pakistan. This country would like a code allowing them to **multiply** two positive numbers, but they have a lot of restrictions.

### Input
1. The first line contains the integer N, that is the number of multiplications to be done.
2. The next N lines contain the positive numbers to be multiplied.

```
2
3 4
13 3
```

### Output
```
12
39
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
for      | 1
while    | 1
*        | 0
/        | 0
%        | 0
+        | 0
-        | 0
++       | 0
--       | 0
sum      | 0
add      | 0
mult     | 0
accumulate | 0
math | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0