L'Inde a aussi voté une loi semblable à celle du Pakistan.  Elle aimerait un code leur permettant de **multiplier** deux nombres positifs, mais ils ont énormément de restrictions.

### Entrée
1. La première ligne contient le nombre entier N, soit le nombre de multiplications à faire.
2. Les N prochaines lignes contiennent les nombres positifs à multiplier.

```
2
3 4
13 3
```

### Sortie
```
12
39
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
for      | 1
while    | 1
*        | 0
/        | 0
%        | 0
+        | 0
-        | 0
++       | 0
--       | 0
sum      | 0
add      | 0
mult     | 0
accumulate | 0
math | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0