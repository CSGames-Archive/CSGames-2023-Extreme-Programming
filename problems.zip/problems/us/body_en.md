Now that the impeachment of Donald Trump is complete, a new president must be re-elected. However, compared to Iran, there are many more people in the country. It will be necessary to write an algorithm to find the majority number much faster (O(n)).

To be a majority, the number must appear more than 50% of the time. Here is an example :
```
2 3 4 5 5 -> No majority
2 2 2 3 5 -> 2 is the majority
2 2 3 4 -> No majority
```

### Input
1. The first line contains the integer N, the number of lines containing numbers.
2. The next N lines contain positive integers separated by spaces.

Note that the number of numbers per line may change!

```
3
2 3
4 2 2 5
2
```

### Output
Return the majority number if available, otherwise return -1 if there is none.

```
2
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
include | 2
import | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0