En Afrique du Sud, il y a plus de 11 langues officielles.  Afin de les aider à chercher un mot dans leur vocabulaire riche, ils ont besoin d'un algorithme de tri pour les mots.

L'algorithme ne doit **pas être sensible aux majuscules et minuscules**!

### Entrée
1. L'entrée contient une seule ligne avec des mots ([a-zA-Z]+) séparés par un espace.  Il n'y a aucun chiffre et aucune ponctuation.

```
Poulet poule Fleur taBLe Patte
```

### Sortie
Retourner les mots triés séparés par un espace.
```
Fleur Patte poule Poulet taBLe
```

Il est a noté que les mots doivent être **retournés comme à l'entrée** (avec les mêmes majuscules) !

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
sort | 0
order | 0
set | 0
map | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0