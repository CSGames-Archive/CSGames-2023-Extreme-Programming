In South Africa there are more than 11 official languages. In order to help them search for a word in their rich vocabulary, they need a word sorting algorithm.

The algorithm must ** not be sensitive to upper and lower case **!

### Input
1. The entry contains only one line with words ([a-zA-Z]+) separated by a space. Also, there are no numbers and no punctuation marks.

```
Poulet poule Fleur taBLe Patte
```

### Output
Return sorted words separated by a space.
```
Fleur Patte poule Poulet taBLe
```

Note that the words must be ** returned the same way as the input ** (with the same capital letters)!

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
sort | 0
order | 0
set | 0
map | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0