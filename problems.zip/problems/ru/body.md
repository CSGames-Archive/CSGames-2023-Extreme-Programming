Le président Vladimir Vladimirovich Putin aimerait un mini programme qui retourne l'entrée qu'il reçoit.

N'oubliez pas que ce sont **les entrées et les sorties standards** sont utilisées !

Vous devez récupérer l'entrée **comme si** vous vouliez récupérer le texte que vous entrez sur votre **clavier**.

### Entrée

Vous recevrez une chaîne de caractères en entrée.  Exemple:

```
J'aime la poutine
```

### Sortie

Vous devez retourner le texte que vous obtenez en entrée telle quelle dans la sortie standard.

```
J'aime la poutine
```

### Restrictions

Aucune.