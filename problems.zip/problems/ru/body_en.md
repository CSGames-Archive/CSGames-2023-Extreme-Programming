President Vladimir Vladimirovich Putin would like a mini program that returns the input it receives.

Remember that these are the **standard inputs and outputs** are used!

You must recover the input ** as if ** you wanted to recover the text that you entered on your ** keyboard**.

### Input

You will receive a string as input. Example:

```
J'aime la poutine
```

### Output

You must return the text you get as input to standard output.

```
J'aime la poutine
```

### Restrictions

None.