The Democratic Republic of the Congo needs your help to determine if a number is a power of 2 with a ** limited number of characters ** in your code. This limit is in the * Restrictions * section below.

### Input

One number N > 0. Example:
```
4
```

### Output
 
Return 1 if the number is a power of two, 0 otherwise.  Example with the input 4 :

```
1
```

### Restrictions

**IT IS HIGHLY RECOMMENDED TO USE PYTHON FOR THIS PROBLEM**

Code length limit: 55