La République démocratique du Congo a besoin de votre aide pour déterminer si un nombre est une puissance de 2 avec un **nombre de caractères limités** dans votre code.  Cette limite est dans la section *Restrictions* plus bas.

### Entrée

Un seul nombre N > 0. Exemple:
```
4
```

### Sortie

Vous devez retourner 1 si c'est une puissance de 2, 0 sinon. Exemple avec l'entrée 4: 

```
1
```

### Restrictions

**IL EST FORTEMENT RECOMMANDÉ D'UTILISER PYTHON POUR CE PROBLÈME.**

Nombre maximum de caractères: 55