L'Iran va bientôt faire des élections.  Ils ont besoin d'un algorithme qui leur permettra de déterminer si un nombre représente une majorité.

Pour être une majorité, le nombre doit apparaitre plus de 50% du temps.  Voici un exemple :
```
2 3 4 5 5 -> Aucune majorité
2 2 2 3 5 -> 2 est la majorité
2 2 3 4 -> Aucune majorité
```

### Entrée
1. La première ligne contient le nombre entier N, soit le nombre de lignes contenant des nombres.
2. Les N prochaines lignes contiennent des nombres entiers positifs séparés par des espaces.

Il est à noter que la quantité de nombres par ligne peut changer !

```
3
2 3
4 2 2 5
2
```

### Sortie
Retourner le nombre majoritaire si disponible, sinon retourner -1 s'il n'y en a pas.

```
2
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
include | 2
import | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0