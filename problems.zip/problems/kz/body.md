Vous devez faire la multiplication de deux nombres sans utiliser les opérateurs * et / et **avec un nombre limité de =**.

### Entrée
1. La première ligne contient le nombre entier N > 0, soit le nombre de multiplications à faire.
2. Les N prochaines lignes contiennent les deux nombres à multiplier.  Il est à noter que ces nombres sont tous supérieurs ou égaux à 0.

```
2
9 3
2 2
```

### Sortie
```
27
4
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
for      | 1
while    | 0
+        | 1
-        | 1
*        | 0
/        | 0
++       | 0
--       | 0
%        | 0
=        | 2
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0