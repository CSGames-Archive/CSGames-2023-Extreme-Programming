Vous devez faire la multiplication de deux nombres sans utiliser les opérateurs de multiplication ou de division. Vous retrouverez la liste complète des mots clefs restreints plus bas.

### Entrée
1. La première ligne contient le nombre entier N, soit le nombre de multiplications à faire.
2. Les N prochaines lignes contiennent les deux nombres à multiplier.

```
2
3 4
13 8
```

### Sortie
```
12
104
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
*        | 0
/        | 0
%        | 0
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0