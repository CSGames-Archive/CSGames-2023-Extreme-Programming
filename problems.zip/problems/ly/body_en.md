You must multiply two numbers without using the multiplication or division operators. You will find the full list of restricted keywords below.

### Input
1. The first line contains the whole number N, which is the number of multiplications to be done.
2. The next N lines contain the two numbers to be multiplied.

```
2
3 4
13 8
```

### Output
```
12
104
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
*        | 0
/        | 0
%        | 0
accumulate | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0