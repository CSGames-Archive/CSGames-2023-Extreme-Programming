The Sinaloa cartel has taken control of the government. Having a lot of money transactions to do, they want a function that allows them to add two positive numbers, but without using any arithmetic operators. This way, their transactions will be more difficult to trace.

### Input
1. The first line contains the whole number N, which is the number of additions to be made.
2. The next N lines contain the positive numbers to add.

```
2
3 4
13 3
```

### Output
```
7
16
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
for      | 1
while    | 1
*        | 0
/        | 0
%        | 0
+        | 0
-        | 0
++       | 0
--       | 0
sum      | 0
add      | 0
mult     | 0
accumulate | 0
math | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0