Le cartel de Sinaloa a pris le contrôle du gouvernement.  Ayant beaucoup de transactions d'argent à effectuer, il voudrait une fonction qui leur permet d'additionner deux nombres positifs, mais sans utiliser d'opérateur arithmétique.  De cette façon, leurs transactions seront plus difficiles à retracer.

### Entrée
1. La première ligne contient le nombre entier N, soit le nombre d'addition à faire.
2. Les N prochaines lignes contiennent les nombres positifs à additionner.

```
2
3 4
13 3
```

### Sortie
```
7
16
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
for      | 1
while    | 1
*        | 0
/        | 0
%        | 0
+        | 0
-        | 0
++       | 0
--       | 0
sum      | 0
add      | 0
mult     | 0
accumulate | 0
math | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0