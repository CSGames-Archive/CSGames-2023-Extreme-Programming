The government discovered that some people in its population have caught the virus from China, the Heinekenvirus. Your mandate is to write a code that will simulate the evolution of the virus. It will allow them to anticipate the spread of the virus.

The simulation works as follows:
1. Each second is represented by an iteration.
2. The virus takes 3 seconds (or 3 iterations) to mature in a cell and explode.
3. When the virus explodes, it infects adjacent uninfected cells.
4. A cell that has just exploded regenerates instantly.

Here is an example:

<pre>
  0       1       2       3       4       5       6     ...
1000    2000    3000    0100    0200    0300    1011
2000 -> 3000 -> 0100 -> 1201 -> 2302 -> 3013 -> 0120 -> ...
0001    0002    1003    2010    3020    0130    1201
</pre>

* Uninfected cells are at 0.
* The infected cells are represented by 1, 2 and 3.

### Input
1. The first line contains m (Number of rows), n (Number of columns) and k (Number of iterations).
2. The following lines contain the state of the cells in the initial state (k=0).

```
2 3 3
001 
200
```

---
**In the initial state, a cell can be infected in an advanced state (therefore have a value of 1, 2 or 3).**

---

### Output
Return the state of the simulation after k iterations
```
210
021
```

### Restrictions

None.