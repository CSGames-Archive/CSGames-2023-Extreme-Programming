Le gouvernement a découvert que certaines personnes dans sa population ont contracté le virus qui provient de la chine, le Heinekenvirus.  Votre mandat est d'écrire un code qui fera une simulation de l'évolution du virus qui leur permettrait d'anticiper la propagation du virus.  

La simulation fonctionne comme suit:
1. Chaque seconde est représentée par une itération.
2. Le virus prend 3 secondes (ou 3 itérations) pour maturer dans une cellule et exploser.
3. Lorsque le virus explose, il contamine les cellules adjacentes non infectées.
4. Une cellule qui vient d'exploser se régénère instantanément.

Voici un exemple:

<pre>
  0       1       2       3       4       5       6     ...
1000    2000    3000    0100    0200    0300    1011
2000 -> 3000 -> 0100 -> 1201 -> 2302 -> 3013 -> 0120 -> ...
0001    0002    1003    2010    3020    0130    1201
</pre>

* Les cellules non infectées sont à 0.
* Les cellules infectées sont représentées par 1, 2 et 3.

### Entrée
1. La première ligne contient m (Nombre de rangées), n (Nombre de colonnes) et k (Nombre d'itérations).
2. Les lignes suivantes contiennent l'état des cellules à l'état initial (k=0).

```
2 3 3
001 
200
```

---
**À l'état initial, une cellule peut être infectée à un état avancé (donc, avoir une valeur de 1, 2 ou 3).**

---

### Sortie
Il faut retourner l'état de la simulation après k itérations
```
210
021
```

### Restrictions

Aucune restriction.