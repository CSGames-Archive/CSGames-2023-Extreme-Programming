We need a somewhat special sorting algorithm. Instead of sorting on the value of the number, we want to sort the numbers based on its bits which are on.

Every number will be between 0 and 255.  In other words, they will all be encoded on 8 bits.
Here is the priority order of the bits : **5 3 6 4 1 8 2 7**.

Here is an example with the numbers 128, 24, 8 et 10.

<pre>
order  5364 1827
128 -> 1000 0000
24  -> 0001 1000
8   -> 0000 1000
10  -> 0000 1010
</pre>

We start by looking at the numbers with the 4th bit on. We have the numbers 10, 24 and 8. Then, the only one with the 2nd bit turned on is 10, so this is our first number.
Then, among the 2 remaining, none has the 7th bit turned on, so we look at the one with the 5th bit turned on and there is only the number 24. Then we have the number 8 and finally the last number is 128.

The output of the sorted array would be 10, 24, 8, 128

### Input
1. The entry contains a single line with a serie of numbers between 0 and 255 separated by a space.

```
11 32 0 58 74 8 2 34
```

### Output

```
74 58 11 8 34 2 32 0
```

### Restrictions

Here is the list of restricted keywords and the number of times you are allowed to use them in your code.

Keyword | Number allowed
---      | ---
sort | 0
order | 0
set | 0
map | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0