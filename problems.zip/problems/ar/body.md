Nous avons besoin d'un algorithme de tri un peu spécial.  Au lieu de trier sur la valeur du nombre, nous voulons trier les nombres basés sur ses bits qui sont à 1.

Tous les nombres seront entre 0 et 255. En d'autres mots, ils seront tous encodés sur 8 bits.
Voici l'ordre de priorité des bits : **5 3 6 4 1 8 2 7**.

Voici un exemple avec les nombres 128, 24, 8 et 10.

<pre>
ordre  5364 1827
128 -> 1000 0000
24  -> 0001 1000
8   -> 0000 1000
10  -> 0000 1010
</pre>

On commence par regarder les nombres avec le 4e bit allumé.  Nous avons les nombres 10, 24 et 8.  Ensuite, le seul avec le 2e bit allumé est 10, donc c'est notre premier nombre.
Ensuite, parmi les 2 nombres restants, il n'y en a aucun qui a le 7e bit allumé, donc nous regardons celui qui a le 5e bit allumé et c'est le nombre 24.  Il nous reste donc juste le 8.
Finalement, le dernier nombre est 128 puisque c'est le seul restant.

En ordre, nous aurions donc 10, 24, 8, 128 comme liste triée.

### Entrée
1. L'entrée contient une seule ligne contenant une série de nombres entre 0 et 255 séparés par des espaces.

```
11 32 0 58 74 8 2 34
```

### Sortie

```
74 58 11 8 34 2 32 0
```

### Restrictions

Voici la liste des mots clefs restreints ainsi que le nombre de fois que vous pouvez l'utiliser au maximum dans tout votre code.

Mot clef | Nombre permis
---      | ---
sort | 0
order | 0
set | 0
map | 0
exec | 0
eval | 0
builtins | 0
attr | 0
__dict__ | 0