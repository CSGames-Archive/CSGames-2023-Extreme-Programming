Les pingouins de Madagascar sont restés trop longtemps dans l'ombre.  Ils ont besoin d'une nouvelle mission et rien de mieux que le problème du Heinekenvirus qui semble se propager en Asie.

Skipper, Kowalski, Rico et Private ont besoin de votre aide.  Ils ont volé les informations que la Thaïlande avait sur le comportement du virus, mais ils ont trouvé quelques erreurs.
En effet, les Thaïlandais n'ont pas pris en compte que les cellules ne sont pas toujours collées.  Parfois, il y a des espaces entre eux.

Voici les nouvelles règles:
1. Certaines cases n'ont **pas de cellules**.
2. Lorsqu'une cellule avec un virus explose, le virus se propage au maximum de **deux cases avant de mourir**.
3. Lorsqu'une cellule explose, elle **meurt définitivement** !

Bien sûr, la plupart des anciennes règles s'appliquent toujours :
1. Chaque seconde est représentée par une itération.
2. Le virus prend 3 secondes (ou 3 itérations) pour maturer dans une cellule et exploser.
3. Lorsque le virus explose, il contamine les cellules adjacentes non infectées.

Attention !  Dû à la nouvelle règle, une cellule qui vient d'exploser **ne se régénère pas instantanément**.

Voici un exemple:

<pre>
  0       1       2       3       4       5       6     ...
1XX0    2XX0    3XX0    XXX0    XXX0    XXX0    XXX1
2X00 -> 3X00 -> XX10 -> XX21 -> XX32 -> XXX3 -> XXXX -> ...
X001    X002    X003    X01X    X02X    X03X    X1XX
</pre>

* Les cellules non infectées sont à 0.
* Les cellules infectées sont représentées par 1, 2 et 3.
* Les X représentent l'absence de cellule à cet endroit.

### Entrée
1. La première ligne contient m (Nombre de rangées), n (Nombre de colonnes) et k (Nombre d'itérations).
2. Les lignes suivantes contiennent l'état des cellules à l'état initial (k=0).

```
2 3 3
0X1 
20X
```

---
**À l'état initial, une cellule peut être infectée à un état avancé (donc avoir une valeur de 1, 2 ou 3).**

---

### Sortie
Il faut retourner l'état de la simulation après k itérations
```
2XX
X2X
```

### Restrictions

Aucune restriction.