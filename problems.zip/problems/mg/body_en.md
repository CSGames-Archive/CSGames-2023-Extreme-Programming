Madagascar's penguins have been in the shadows for too long. They need a new mission and it seems like the Heinekenvirus is the perfect opportunity.

Skipper, Kowalski, Rico and Private need your help. They stole the information that Thailand had about the behaviour of the virus, but they found some errors.
Indeed, the Thai people did not take into account that sometimes there are spaces between the cells.

Here are the new rules:
5. Some boxes have ** no cells **.
6. When a cell with a virus explodes, the virus spreads by a maximum of ** two cells before dying **.
7. When a cell explodes, it ** dies definitively **!

Of course, most of the old rules still apply:
1. Each second is represented by an iteration.
2. The virus takes 3 seconds (or 3 iterations) to mature in a cell and explode.
3. When the virus explodes, it infects adjacent uninfected cells.

Warning ! Due to the new rule, a cell that has just exploded ** does not regenerate instantly **.

Here is an example:

<pre>
  0       1       2       3       4       5       6     ...
1XX0    2XX0    3XX0    XXX0    XXX0    XXX0    XXX1
2X00 -> 3X00 -> XX10 -> XX21 -> XX32 -> XXX3 -> XXXX -> ...
X001    X002    X003    X01X    X02X    X03X    X1XX
</pre>

* Uninfected cells are at 0.
* The infected cells are represented by 1, 2 and 3.
* The Xs represent the absence of cells at this location.

### Input
1. The first line contains m (Number of rows), n (Number of columns) and k (Number of iterations).
2. The following lines contain the state of the cells in the initial state (k=0).

```
2 3 3
0X1 
20X
```

---
**In the initial state, a cell can be infected in an advanced state (therefore have a value of 1, 2 or 3).**

---

### Output
Return the state of the simulation after k iterations
```
2XX
X2X
```

### Restrictions

No restriction.